<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include 'db_connect.php';

$task_id = $_GET['id'];
$user_id = $_SESSION['user_id'];

// Delete the task
$query = "DELETE FROM tasks WHERE id = ? AND user_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("ii", $task_id, $user_id);

if ($stmt->execute()) {
    // Optional: Delete associated submissions if needed
    $submit_query = "DELETE FROM submitted WHERE task_id = ?";
    $submit_stmt = $conn->prepare($submit_query);
    $submit_stmt->bind_param("i", $task_id);
    $submit_stmt->execute();
    
    header("Location: dashboard.php");
    exit();
} else {
    echo "Error deleting task.";
}
?>
