<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include 'db_connect.php';

$user_id = $_SESSION['user_id'];
$task_id = $_GET['task_id'];

// Fetch submitted work for the specific task
$query = "SELECT * FROM submitted WHERE task_id = ? AND user_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("ii", $task_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();

$submitted = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Submitted Work</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            padding: 20px;
            background-color: #f9f9f9;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        h2 { color: #333; }
    </style>
</head>
<body>
    <h2>Your Submitted Work</h2>

    <?php if ($submitted): ?>
        <p>File Path: <a href="<?php echo htmlspecialchars($submitted['file_path']); ?>" target="_blank">View Submitted File</a></p>
    <?php else: ?>
        <p>No work submitted for this task.</p>
    <?php endif; ?>

    <a href="dashboard.php">Back to Dashboard</a>
</body>
</html>
