<?php
// Start session
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Database connection
include 'db_connect.php';

// Handle the submission of work
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit_work'])) {
    $user_id = $_SESSION['user_id'];
    $work_title = $_POST['work_title'];
    $work_description = $_POST['work_description'];

    // Insert submitted work into the database
    $insert_query = "INSERT INTO submissions (user_id, title, description) VALUES (?, ?, ?)";
    $insert_stmt = $conn->prepare($insert_query);
    $insert_stmt->bind_param("iss", $user_id, $work_title, $work_description);

    if ($insert_stmt->execute()) {
        // Redirect to the same page to display the newly added submission
        header("Location: dashboard.php");
        exit();
    } else {
        $error_message = "Error submitting your work!";
    }
}

// Fetch user submissions
$user_id = $_SESSION['user_id'];
$query = "SELECT * FROM submissions WHERE user_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$submissions = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background: white;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
        }
        .submission-form {
            margin-bottom: 20px;
            padding: 20px;
            background: #e9ecef;
            border-radius: 5px;
        }
        .submission-form input, .submission-form textarea {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .submission-form button {
            background-color: #5cb85c;
            color: white;
            border: none;
            border-radius: 5px;
            padding: 10px;
            cursor: pointer;
        }
        .submission-form button:hover {
            background-color: #4cae4c;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 8px 12px;
            border: 1px solid #ddd;
        }
        th {
            background-color: #f4f4f4;
        }
        .logout-button {
            display: block;
            width: 100%;
            padding: 10px;
            margin: 20px 0;
            background-color: #d9534f;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-align: center;
        }
        .logout-button:hover {
            background-color: #c9302c;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Your Tasks</h2>
        <a href="add-task.php">Add New Task</a>

        <!-- Submission Form -->
        <div class="submission-form">
            <h3>New Submission</h3>
            <?php if (isset($error_message)) { echo "<p style='color:red;'>$error_message</p>"; } ?>
            <form method="POST" action="">
                <input type="text" name="work_title" placeholder="Work Title" required>
                <textarea name="work_description" placeholder="Work Description" required></textarea>
                <button type="submit" name="submit_work">Submit Work</button>
            </form>
        </div>

        <!-- Displaying User Submissions -->
        <h3>Your Submissions</h3>
        <table>
            <tr>
                <th>Title</th>
                <th>Description</th>
            </tr>
            <?php if (count($submissions) > 0): ?>
                <?php foreach ($submissions as $submission): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($submission['title']); ?></td>
                        <td><?php echo htmlspecialchars($submission['description']); ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="2">No submissions found. Please submit your work!</td>
                </tr>
            <?php endif; ?>
        </table>

        <!-- Logout button -->
        <form action="logout.php" method="POST">
            <button type="submit" class="logout-button">Logout</button>
        </form>
    </div>
</body>
</html>
