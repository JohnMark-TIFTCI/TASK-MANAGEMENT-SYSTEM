<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST['title'];
    $deadline = $_POST['deadline'];
    $user_id = $_SESSION['user_id'];

    $query = "INSERT INTO tasks (user_id, title, deadline) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("iss", $user_id, $title, $deadline);

    if ($stmt->execute()) {
        header("Location: dashboard.php");
        exit();
    } else {
        $error_message = "Failed to create task.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Task</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            padding: 20px;
            background-color: #f9f9f9;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        h2 { color: #333; }
        form { margin-bottom: 20px; }
        label { display: block; margin: 10px 0 5px; }
        input[type="text"], input[type="date"] {
            width: 100%; padding: 10px; margin-bottom: 10px; border: 1px solid #ddd; border-radius: 4px;
        }
        button {
            padding: 10px 15px; background-color: #5cb85c; color: white; border: none; border-radius: 4px; cursor: pointer;
        }
        button:hover { background-color: #4cae4c; }
        .error { color: red; }
    </style>
</head>
<body>
    <h2>Add Task</h2>
    <?php if (isset($error_message)) { echo "<p class='error'>$error_message</p>"; } ?>
    <form method="POST" action="">
        <label for="title">Task Title:</label>
        <input type="text" name="title" required>
        <label for="deadline">Deadline:</label>
        <input type="date" name="deadline" required>
        <button type="submit">Add Task</button>
    </form>
    <a href="dashboard.php">Back to Dashboard</a>
</body>
</html>
