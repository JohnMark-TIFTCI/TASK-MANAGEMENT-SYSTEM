<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include 'db_connect.php';

$task_id = $_GET['id'];
$user_id = $_SESSION['user_id'];

// Fetch the task data for the given task ID
$query = "SELECT * FROM tasks WHERE id = ? AND user_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("ii", $task_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();
$task = $result->fetch_assoc();

// If the task does not exist or belongs to another user, redirect to dashboard
if (!$task) {
    header("Location: dashboard.php");
    exit();
}

// Handle the form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Optional file upload
    $file_path = '';
    if (isset($_FILES['submission']) && $_FILES['submission']['error'] == UPLOAD_ERR_OK) {
        $upload_dir = 'uploads/';
        $file_name = basename($_FILES['submission']['name']);
        $file_path = $upload_dir . $file_name;

        // Ensure the uploads directory exists
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }

        // Move the uploaded file to the specified directory
        if (!move_uploaded_file($_FILES['submission']['tmp_name'], $file_path)) {
            $error_message = "Failed to upload file.";
        }
    }

    // Update the task in the database and set status to "Completed"
    $update_query = "UPDATE tasks SET status = 'Completed' WHERE id = ? AND user_id = ?";
    $update_stmt = $conn->prepare($update_query);
    $update_stmt->bind_param("ii", $task_id, $user_id);
    if ($update_stmt->execute()) {
        // If a file was uploaded, insert it into the submitted table
        if ($file_path) {
            $submit_query = "INSERT INTO submitted (task_id, user_id, file_path) VALUES (?, ?, ?)";
            $submit_stmt = $conn->prepare($submit_query);
            $submit_stmt->bind_param("iis", $task_id, $user_id, $file_path);
            $submit_stmt->execute();
        }
        header("Location: dashboard.php"); // Redirect to dashboard after successful submission
        exit();
    } else {
        $error_message = "Failed to update task status.";
    }
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Task</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            padding: 20px;
            background-color: #f9f9f9;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        h2 { color: #333; }
        label { display: block; margin: 10px 0 5px; }
        input[type="text"], input[type="date"], input[type="file"] {
            width: 100%; padding: 10px; margin-bottom: 10px; border: 1px solid #ddd; border-radius: 4px;
        }
        button {
            padding: 10px 15px; background-color: #5cb85c; color: white; border: none; border-radius: 4px; cursor: pointer;
        }
        button:hover { background-color: #4cae4c; }
        .error { color: red; }
    </style>
</head>
<body>
    <h2>Edit Task</h2>
    
    <!-- Error message if any -->
    <?php if (isset($error_message)) { echo "<p class='error'>$error_message</p>"; } ?>
    
    <!-- Task Edit Form -->
    <form method="POST" enctype="multipart/form-data" action="">
        <label for="submission">Upload Work:</label>
        <input type="file" name="submission">

        <button type="submit">Submit Work</button>
    </form>

    <h3>Current Task Status: <?php echo htmlspecialchars($task['status']); ?></h3>

    <a href="dashboard.php">Back to Dashboard</a>
</body>
</html>
