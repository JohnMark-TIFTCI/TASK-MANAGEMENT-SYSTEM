<?php
session_start();

// Redirect to login page if user is not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Connect to the database
include 'db_connect.php';

$task_id = $_GET['id'];
$user_id = $_SESSION['user_id'];

// Fetch the task data for the given task ID
$query = "SELECT * FROM tasks WHERE id = ? AND user_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("ii", $task_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();
$task = $result->fetch_assoc();

// If the task does not exist or belongs to another user, redirect to dashboard
if (!$task) {
    header("Location: dashboard.php");
    exit();
}

// Handle the form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $deadline = $_POST['deadline'];

    // Validate the form data (you can add more validation as needed)
    if (!empty($title) && !empty($deadline)) {
        // Update the task in the database
        $update_query = "UPDATE tasks SET title = ?, description = ?, deadline = ? WHERE id = ? AND user_id = ?";
        $update_stmt = $conn->prepare($update_query);
        $update_stmt->bind_param("sssii", $title, $description, $deadline, $task_id, $user_id);
        if ($update_stmt->execute()) {
            header("Location: dashboard.php"); // Redirect to dashboard after successful update
            exit();
        } else {
            $error_message = "Failed to update task.";
        }
    } else {
        $error_message = "Please fill out all required fields.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Task</title>
    <style>
        /* Add the same CSS styles from the login page */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 400px;
            margin: 50px auto;
            padding: 20px;
            background: white;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
        }
        input[type="text"],
        input[type="date"],
        textarea,
        button {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            background-color: #5cb85c;
            color: white;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: #4cae4c;
        }
        .error {
            color: red;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Edit Task</h2>
        
        <!-- Error message if any -->
        <?php if (isset($error_message)) { echo "<p class='error'>$error_message</p>"; } ?>
        
        <!-- Task Edit Form -->
        <form method="POST" action="">
            <label for="title">Title:</label>
            <input type="text" name="title" value="<?php echo htmlspecialchars($task['title']); ?>" required><br>

            <label for="description">Description:</label>
            <textarea name="description"><?php echo htmlspecialchars($task['description']); ?></textarea><br>

            <label for="deadline">Deadline:</label>
            <input type="date" name="deadline" value="<?php echo htmlspecialchars($task['deadline']); ?>" required><br>

            <button type="submit">Update Task</button>
        </form>

        <a href="dashboard.php">Back to Dashboard</a>
    </div>
</body>
</html>
