<?php
session_start();

// Redirect to login page if user is not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Connect to the database
include 'db_connect.php';

$task_id = $_GET['id'];
$user_id = $_SESSION['user_id'];

// Check if the task belongs to the logged-in user
$query = "SELECT * FROM tasks WHERE id = ? AND user_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("ii", $task_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();
$task = $result->fetch_assoc();

// If the task does not exist or belongs to another user, redirect to dashboard
if (!$task) {
    header("Location: dashboard.php");
    exit();
}

// Delete the task from the database
$delete_query = "DELETE FROM tasks WHERE id = ? AND user_id = ?";
$delete_stmt = $conn->prepare($delete_query);
$delete_stmt->bind_param("ii", $task_id, $user_id);
if ($delete_stmt->execute()) {
    header("Location: dashboard.php"); // Redirect to dashboard after deletion
    exit();
} else {
    $error_message = "Failed to delete task.";
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Delete Task</title>
</head>
<body>
    <h2>Delete Task</h2>
    
    <!-- Error message if any -->
    <?php if (isset($error_message)) { echo "<p>$error_message</p>"; } ?>
    
    <a href="dashboard.php">Back to Dashboard</a>
</body>
</html>
