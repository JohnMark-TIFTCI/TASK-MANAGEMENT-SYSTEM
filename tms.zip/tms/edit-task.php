<?php
session_start();

// Redirect to login page if user is not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Connect to the database
include 'db_connect.php';

$task_id = $_GET['id'];
$user_id = $_SESSION['user_id'];

// Fetch the task data for the given task ID
$query = "SELECT * FROM tasks WHERE id = ? AND user_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("ii", $task_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();
$task = $result->fetch_assoc();

// If the task does not exist or belongs to another user, redirect to dashboard
if (!$task) {
    header("Location: dashboard.php");
    exit();
}

// Handle the form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $deadline = $_POST['deadline'];
    
    // Check if a file is uploaded
    $status = "Pending"; // Default status
    if (isset($_FILES['work_file']) && $_FILES['work_file']['error'] === UPLOAD_ERR_OK) {
        $file_tmp_path = $_FILES['work_file']['tmp_name'];
        $file_name = $_FILES['work_file']['name'];
        $file_size = $_FILES['work_file']['size'];
        $file_type = $_FILES['work_file']['type'];

        // Set the upload directory
        $upload_dir = 'images/';
        $file_path = $upload_dir . basename($file_name);

        // Move the file to the desired directory
        if (move_uploaded_file($file_tmp_path, $file_path)) {
            $status = "Completed"; // Update status to completed if file is uploaded
        }
    }

    // Validate the form data
    if (!empty($title) && !empty($deadline)) {
        // Update the task in the database
        $update_query = "UPDATE tasks SET title = ?, description = ?, deadline = ?, status = ? WHERE id = ? AND user_id = ?";
        $update_stmt = $conn->prepare($update_query);
        $update_stmt->bind_param("sssiii", $title, $description, $deadline, $status, $task_id, $user_id);
        if ($update_stmt->execute()) {
            header("Location: dashboard.php"); // Redirect to dashboard after successful update
            exit();
        } else {
            $error_message = "Failed to update task.";
        }
    } else {
        $error_message = "Please fill out all required fields.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Task</title>
    <style>
        body {
            background-image: url('https://img2.tapimg.net/post/images/FrNV_d3I2nY5zXxVm-A9kG2-dr9S.jpeg?imageMogr2/thumbnail/720x9999%3E/quality/80/format/jpg/interlace/1/ignore-error/1'); /* Replace with your image URL */
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            height: 100vh;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            color: white;
        }
        .container {
            background-color: rgba(0, 0, 0, 0.7);
            padding: 40px;
            border-radius: 10px;
            width: 400px;
            box-shadow: 0px 15px 30px rgba(0, 0, 0, 0.5);
        }
        h2 {
            text-align: center;
            color: #00ff00;
        }
        label {
            display: block;
            margin: 10px 0 5px;
            color: #ffcc00;
        }
        input[type="text"],
        input[type="date"],
        textarea,
        input[type="file"] {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 2px solid #333;
            border-radius: 8px;
            background-color: #222;
            color: white;
        }
        textarea {
            height: 100px;
            resize: none;
        }
        button {
            width: 100%;
            padding: 12px;
            background-color: #ff006e;
            color: #00ff00;
            border: none;
            border-radius: 8px;
            cursor: pointer;
        }
        button:hover {
            background-color: #ff00ff;
        }
        .error {
            color: #ffcc00;
            text-align: center;
            margin-bottom: 20px;
        }
        a {
            color: #00ff00;
            text-decoration: none;
            text-align: center;
            display: block;
            margin-top: 20px;
        }
        a:hover {
            color: #ffcc00;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Edit Task</h2>

        <!-- Error message if any -->
        <?php if (isset($error_message)) { echo "<p class='error'>$error_message</p>"; } ?>

        <!-- Task Edit Form -->
        <form method="POST" action="" enctype="multipart/form-data">
            <label for="title">Title:</label>
            <input type="text" name="title" value="<?php echo htmlspecialchars($task['title']); ?>" required><br>

            <label for="description">Description:</label>
            <textarea name="description"><?php echo htmlspecialchars($task['description']); ?></textarea><br>

            <label for="deadline">Deadline:</label>
            <input type="date" name="deadline" value="<?php echo htmlspecialchars($task['deadline']); ?>" required><br>

            <label for="work_file">Upload Your Work:</label>
            <input type="file" name="work_file" accept=".jpg,.jpeg,.png,.pdf" required><br>

            <button type="submit">Update Task</button>
        </form>

        <a href="dashboard.php">Back to Dashboard</a>
    </div>
</body>
</html>
