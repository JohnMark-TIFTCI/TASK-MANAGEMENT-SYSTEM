<?php
session_start();

include 'db_connect.php';

$error_message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if (!empty($username) && !empty($password)) {
        // Check if username already exists
        $query = "SELECT * FROM users WHERE username = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $error_message = "Username already exists. Please choose another.";
        } else {
            // Insert the new user into the database
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $insert_query = "INSERT INTO users (username, password) VALUES (?, ?)";
            $insert_stmt = $conn->prepare($insert_query);
            $insert_stmt->bind_param("ss", $username, $hashed_password);
            if ($insert_stmt->execute()) {
                header("Location: login.php"); // Redirect to login page after successful registration
                exit();
            } else {
                $error_message = "Failed to register. Please try again.";
            }
        }
    } else {
        $error_message = "Please fill out all required fields.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
    <style>
        body {
            /* Replace 'your-image-url.jpg' with the actual URL or path to your image */
            background-image: url('https://wallpapers.com/images/featured/solo-leveling-2jfg776ajtuvmav9.jpg');
            background-size: cover; /* Ensures the image covers the entire background */
            background-position: center; /* Centers the image in the viewport */
            background-repeat: no-repeat; /* Prevents the image from repeating */
            height: 100vh; /* Ensures the body takes the full height of the viewport */
            margin: 0; /* Removes default margin */
            display: flex; /* Flexbox layout for centering content */
            justify-content: center; /* Horizontally centers child elements */
            align-items: center; /* Vertically centers child elements */
            color: white; /* Sets the text color to white for contrast */
        }
        .register-container {
            background-color: rgba(0, 0, 0, 0.7); /* Dark background for form */
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0px 15px 30px rgba(0, 0, 0, 0.5);
            text-align: center;
            width: 350px;
        }
        h2 {
            margin-bottom: 20px;
            font-size: 28px;
        }
        label {
            font-size: 18px;
            text-align: left;
            display: block;
            margin-bottom: 5px;
        }
        input[type="text"], 
        input[type="password"] {
            width: 100%;
            padding: 12px 20px;
            margin-bottom: 15px;
            border: none;
            border-radius: 30px;
            outline: none;
            font-size: 16px;
        }
        button {
            width: 100%;
            padding: 12px 20px;
            border-radius: 30px;
            background-color: #43a047;
            color: white;
            border: none;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        button:hover {
            background-color: #2e7d32;
        }
        .error {
            color: yellow;
            font-size: 16px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="register-container">
        <h2>Register</h2>
        
        <?php if (!empty($error_message)) { echo "<p class='error'>$error_message</p>"; } ?>
        
        <form method="POST" action="register.php">
            <label for="username">Username:</label>
            <input type="text" name="username" required>
            <label for="password">Password:</label>
            <input type="password" name="password" required>
            <button type="submit">Register</button>
        </form>

        <p>Already have an account? <a href="login.php" style="color: #00ff00;">Login here</a></p>
    </div>
</body>
</html>
