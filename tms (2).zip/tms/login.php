<?php
session_start();

if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit();
}

include 'db_connect.php';

$error_message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if (!empty($username) && !empty($password)) {
        $query = "SELECT * FROM users WHERE username = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            header("Location: dashboard.php");
            exit();
        } else {
            $error_message = "Invalid username or password.";
        }
    } else {
        $error_message = "Please enter both username and password.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <style>
        body {
            font-family: 'Comic Sans MS', cursive, sans-serif;
            background-image: url('https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/5fb7d836-1124-43d9-937c-f365d9aeaa8b/de47t1e-2f059e13-7629-4d42-9e1a-05e3e5b1a082.png/v1/fill/w_1280,h_720,q_80,strp/jin_woo_solo_leveling_wallpaper_by_muztnafi_de47t1e-fullview.jpg?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7ImhlaWdodCI6Ijw9NzIwIiwicGF0aCI6IlwvZlwvNWZiN2Q4MzYtMTEyNC00M2Q5LTkzN2MtZjM2NWQ5YWVhYThiXC9kZTQ3dDFlLTJmMDU5ZTEzLTc2MjktNGQ0Mi05ZTFhLTA1ZTNlNWIxYTA4Mi5wbmciLCJ3aWR0aCI6Ijw9MTI4MCJ9XV0sImF1ZCI6WyJ1cm46c2VydmljZTppbWFnZS5vcGVyYXRpb25zIl19._K_immzwFz4CRZcLKo-PqlNiPB_1t9KWa_z21CieHSk'); /* Set your background image URL here */
            background-size: cover; /* Ensures the image covers the entire background */
            background-position: center; /* Centers the image in the viewport */
            background-repeat: no-repeat; /* Prevents the image from repeating */
            height: 100vh; /* Ensures the body takes the full height of the viewport */
            margin: 0; /* Removes default margin */
            display: flex; /* Flexbox layout for centering content */
            align-items: center; /* Vertically centers child elements */
            justify-content: center; /* Horizontally centers child elements */
            color: white; /* Sets the text color to white for contrast */
        }
        .login-container {
            background-color: rgba(0, 0, 0, 0.7); /* Semi-transparent background for the login container */
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0px 15px 30px rgba(0, 0, 0, 0.5);
            text-align: center;
            width: 350px;
        }
        .login-container img {
            width: 100px;
            height: auto;
            margin-bottom: 20px;
        }
        .login-container h2 {
            margin-bottom: 20px;
            font-size: 28px;
        }
        .login-container label {
            font-size: 18px;
            text-align: left;
            display: block;
            margin-bottom: 5px;
        }
        .login-container input[type="text"], 
        .login-container input[type="password"] {
            width: 100%;
            padding: 12px 20px;
            margin-bottom: 15px;
            border: none;
            border-radius: 30px;
            outline: none;
            font-size: 16px;
        }
        .login-container button {
            width: 100%;
            padding: 12px 20px;
            border-radius: 30px;
            background-color: #43a047;
            color: white;
            border: none;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .login-container button:hover {
            background-color: #2e7d32;
        }
        .login-container .error {
            color: yellow;
            font-size: 16px;
            margin-bottom: 20px;
        }
        .login-container .register-btn {
            background-color: #0288d1;
            margin-top: 15px;
        }
        .login-container .register-btn:hover {
            background-color: #0277bd;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h2>Login</h2>
        
        <?php if (!empty($error_message)) { echo "<p class='error'>$error_message</p>"; } ?>
        
        <form method="POST" action="login.php">
            <label for="username">Username:</label>
            <input type="text" name="username" required>
            <label for="password">Password:</label>
            <input type="password" name="password" required>
            <button type="submit">Login</button>
        </form>

        <form action="register.php" method="GET">
            <button class="register-btn" type="submit">Register</button>
        </form>
    </div>
</body>
</html>
