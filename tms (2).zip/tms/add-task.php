<?php
session_start();

// Redirect to login page if user is not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Connect to the database
include 'db_connect.php';

$user_id = $_SESSION['user_id'];

// Handle the form submission for adding a task
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST['title'];
    $description = $_POST['description']; // Get the description input
    $deadline = $_POST['deadline'];

    // Insert the new task into the database
    $insert_query = "INSERT INTO tasks (title, description, deadline, user_id) VALUES (?, ?, ?, ?)";
    $insert_stmt = $conn->prepare($insert_query);
    $insert_stmt->bind_param("sssi", $title, $description, $deadline, $user_id);
    
    if ($insert_stmt->execute()) {
        header("Location: dashboard.php"); // Redirect to dashboard after successful insert
        exit();
    } else {
        $error_message = "Failed to add task.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Task</title>
    <style>
        body {
            background-image: url('https://w0.peakpx.com/wallpaper/36/668/HD-wallpaper-anime-solo-leveling-beru-solo-leveling.jpg'); /* Replace with your image URL */
            background-size: cover; /* Ensures the image covers the entire background */
            background-position: center; /* Centers the image in the viewport */
            background-repeat: no-repeat; /* Prevents the image from repeating */
            height: 100vh; /* Ensures the body takes the full height of the viewport */
            margin: 0; /* Removes default margin */
            display: flex; /* Flexbox layout for centering content */
            justify-content: center; /* Horizontally centers child elements */
            align-items: center; /* Vertically centers child elements */
            color: white; /* Sets the text color to white for contrast */
        }
        .container {
            background-color: rgba(0, 0, 0, 0.7); /* Semi-transparent background */
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0px 15px 30px rgba(0, 0, 0, 0.5);
            width: 400px;
            border: 5px solid #00ff00;
        }
        h2 {
            text-align: center;
            color: #00ff00;
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin: 10px 0 5px;
            color: #ffcc00;
            font-size: 14px;
        }
        input[type="text"],
        input[type="date"],
        textarea {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 2px solid #333;
            border-radius: 8px;
            background-color: #222;
            color: white;
            font-size: 14px;
        }
        textarea {
            height: 100px;
            resize: none;
        }
        button {
            width: 100%;
            padding: 12px;
            background-color: #ff006e;
            color: #00ff00;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 14px;
        }
        button:hover {
            background-color: #ff00ff;
        }
        .error {
            color: #ffcc00;
            text-align: center;
            margin-bottom: 20px;
        }
        a {
            color: #00ff00;
            text-decoration: none;
            text-align: center;
            display: block;
            margin-top: 20px;
        }
        a:hover {
            color: #ffcc00;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Add Task</h2>

        <!-- Error message if any -->
        <?php if (isset($error_message)) { echo "<p class='error'>$error_message</p>"; } ?>

        <!-- Task Add Form -->
        <form method="POST" action="">
            <label for="title">Title:</label>
            <input type="text" name="title" required><br>

            <label for="description">Description:</label>
            <textarea name="description" required></textarea><br>

            <label for="deadline">Deadline:</label>
            <input type="date" name="deadline" required><br>

            <button type="submit">Add Task</button>
        </form>

        <a href="dashboard.php">Back to Dashboard</a>
    </div>
</body>
</html>
