<?php
session_start();

// Redirect to login page if user is not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Connect to the database
include 'db_connect.php';

$user_id = $_SESSION['user_id'];

// Fetch tasks for the logged-in user
$query = "SELECT * FROM tasks WHERE user_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$tasks = $result->fetch_all(MYSQLI_ASSOC);

// Handle the deletion of a task
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];

    // Prepare delete query
    $delete_query = "DELETE FROM tasks WHERE id = ? AND user_id = ?";
    $delete_stmt = $conn->prepare($delete_query);
    $delete_stmt->bind_param("ii", $delete_id, $user_id);

    if ($delete_stmt->execute()) {
        header("Location: dashboard.php"); // Refresh the page after deletion
        exit();
    } else {
        $error_message = "Failed to delete task.";
    }
}

// Handle logout
if (isset($_GET['logout'])) {
    session_destroy(); // Destroy the session
    header("Location: login.php"); // Redirect to login page
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
    <style>
        body {
            background-image: url('https://c4.wallpaperflare.com/wallpaper/465/506/495/dinocozero-collage-solo-leveling-sung-jin-woo-hd-wallpaper-preview.jpg'); /* Replace with your image URL */
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            height: 100vh;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            color: white;
        }
        .container {
            background-color: rgba(0, 0, 0, 0.7);
            padding: 40px;
            border-radius: 10px;
            width: 600px;
            box-shadow: 0px 15px 30px rgba(0, 0, 0, 0.5);
        }
        h2 {
            text-align: center;
            color: #00ff00;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 10px;
            text-align: left;
            border: 1px solid #333;
        }
        th {
            background-color: #444;
            color: #ffcc00;
        }
        tr:nth-child(even) {
            background-color: #222;
        }
        tr:hover {
            background-color: #333;
        }
        button.delete {
            background-color: #ff0000;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            padding: 5px 10px;
        }
        button.delete:hover {
            background-color: #cc0000;
        }
        .error {
            color: #ffcc00;
            text-align: center;
            margin-bottom: 20px;
        }
        a {
            color: #00ff00;
            text-decoration: none;
            text-align: center;
            display: block;
            margin-top: 20px;
        }
        a:hover {
            color: #ffcc00;
        }
        .logout {
            background-color: #ffcc00;
            color: black;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            padding: 5px 10px;
            margin-bottom: 20px;
            text-align: center;
        }
        .logout:hover {
            background-color: #ff9900;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Your Tasks</h2>

        <!-- Logout Button -->
        <a href="dashboard.php?logout=true" class="logout">Logout</a>

        <!-- Error message if any -->
        <?php if (isset($error_message)) { echo "<p class='error'>$error_message</p>"; } ?>

        <!-- Task Table -->
        <table>
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Description</th>
                    <th>Deadline</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($tasks as $task): ?>
                <tr>
                    <td><?php echo htmlspecialchars($task['title']); ?></td>
                    <td><?php echo htmlspecialchars($task['description']); ?></td>
                    <td><?php echo htmlspecialchars($task['deadline']); ?></td>
                    <td><?php echo htmlspecialchars($task['status']); ?></td>
                    <td>
                        <a href="edit-task.php?id=<?php echo $task['id']; ?>">Edit</a>
                        <a href="dashboard.php?delete_id=<?php echo $task['id']; ?>" onclick="return confirm('Are you sure you want to delete this task?');">
                            <button class="delete">Delete</button>
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <a href="add-task.php">Add New Task</a>
    </div>
</body>
</html>
